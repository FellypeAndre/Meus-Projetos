<?php
require 'db.php';

// Verifica se há uma busca sendo feita
if (isset($_POST['search'])) {
    $search = '%' . $_POST['search'] . '%';

    // SQL para buscar cursos pelo nome
    $sql = "SELECT * FROM cursos WHERE nome LIKE :search";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':search', $search);
    $stmt->execute();
    $cursos = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Exibe os resultados da pesquisa
    if ($cursos) {
        foreach ($cursos as $curso) {
            echo "<tr>";
            echo "<td>{$curso['nome']}</td>";
            echo "<td>{$curso['descricao']}</td>";
            echo "<td>
                    <a href='editar_cursos.php?id={$curso['id_cursos']}' class='btn btn-warning btn-sm'>Editar</a>
                    <a href='excluir_cursos.php?id={$curso['id_cursos']}' class='btn btn-danger btn-sm' onclick='return confirm(\"Tem certeza que deseja excluir?\")'>Excluir</a>
                  </td>";
            echo "</tr>";
        }
    } else {
        echo "<tr><td colspan='3'>Nenhum curso encontrado.</td></tr>";
    }
}
?>
