<?php
require 'db.php';

$id = $_GET['id'] ?? null;

if ($id) {
    // Excluir o aluno
    $sql = "DELETE FROM alunos WHERE id_aluno = :id";
    $stmt = $pdo->prepare($sql);
    $stmt->execute(['id' => $id]);

    // Redirecionar para a listagem com uma mensagem de sucesso
    header("Location: listar_alunos.php?msgSucesso=Aluno excluído com sucesso");
    exit;
} else {
    // Redirecionar para a listagem com uma mensagem de erro
    header("Location: listar_alunos.php?msgErro=Erro ao excluir o aluno");
    exit;
}
?>
